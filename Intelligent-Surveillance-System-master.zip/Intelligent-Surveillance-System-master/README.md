# Intelligent-Surveillance-System
Over the previous few decades, outstanding infrastructure growths are noticed in security related
problems throughout the world. So, with multiplied demand for security, videobased
surveillance has become a crucial space for the analysis. An intelligent video surveillance
system primarily censored the performance, happenings, or ever-changing information
typically in terms of human beings, vehicles or the other objects from a distance by means
of some equipment (usually digital camera). The scopes like prevention, detection and
intervention that have led to the development of real and consistent video surveillance
systems are capable of intelligent video processing competencies.
Earlier surveillance systems were more dependent on human operator. Now a days
because of better efficiencies and reliability, automated systems are preferred and in accordance
of security it is very helpful to detect violence. Violence is an abnormal behavior
and those actions can be identified through smart surveillance system which can be used
to prevent further fatal accidents. On large scale this system can be implemented in several
locations like streets, parks, medical centers and alert authorities about the violent
activities.
